-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Час створення: Трв 07 2018 р., 19:36
-- Версія сервера: 5.1.73-log
-- Версія PHP: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `usercT1Z`
--

-- --------------------------------------------------------

--
-- Структура таблиці `frakbank`
--

CREATE TABLE IF NOT EXISTS `frakbank` (
  `FracBank[0][fSfnews]` int(11) NOT NULL,
  `FracBank[0][fKazna]` int(11) NOT NULL,
  `healpric` int(11) NOT NULL,
  `addd[0]` int(11) NOT NULL,
  `addd[1]` int(11) NOT NULL,
  `addd[2]` int(11) NOT NULL,
  `FracBank[0][fBMoney]` int(11) NOT NULL,
  `FracBank[0][fBDrugs]` int(11) NOT NULL,
  `FracBank[0][fBMats]` int(11) NOT NULL,
  `FracBank[0][fVMoney]` int(11) NOT NULL,
  `FracBank[0][fVDrugs]` int(11) NOT NULL,
  `FracBank[0][fVMats]` int(11) NOT NULL,
  `FracBank[0][fGMoney]` int(11) NOT NULL,
  `FracBank[0][fGDrugs]` int(11) NOT NULL,
  `FracBank[0][fGMats]` int(11) NOT NULL,
  `FracBank[0][fCMoney]` int(11) NOT NULL,
  `FracBank[0][fCDrugs]` int(11) NOT NULL,
  `FracBank[0][fCMats]` int(11) NOT NULL,
  `FracBank[0][fRMoney]` int(11) NOT NULL,
  `FracBank[0][fRDrugs]` int(11) NOT NULL,
  `FracBank[0][fRMats]` int(11) NOT NULL,
  `FracBank[0][farmmatbi]` int(11) NOT NULL,
  `FracBank[0][farmmatsf]` int(11) NOT NULL,
  `FracBank[0][flspdmatbi]` int(11) NOT NULL,
  `FracBank[0][ffbimats]` int(11) NOT NULL,
  `FracBank[0][fyakuzamats]` int(11) NOT NULL,
  `FracBank[0][frmmats]` int(11) NOT NULL,
  `FracBank[0][flcnmats]` int(11) NOT NULL,
  `FracBank[0][fsfpdmats]` int(11) NOT NULL,
  `FracBank[0][flvpdmats]` int(11) NOT NULL,
  `FracBank[0][fMMoney]` int(11) NOT NULL,
  `FracBank[0][fMDrugs]` int(11) NOT NULL,
  `FracBank[0][fMMats]` int(11) NOT NULL,
  `FracBank[0][fzmatbi]` int(11) NOT NULL,
  `FracBank[0][fzsklad]` int(11) NOT NULL,
  `FracBank[0][fsklballas]` int(11) NOT NULL,
  `FracBank[0][fsklvagos]` int(11) NOT NULL,
  `FracBank[0][fsklgrove]` int(11) NOT NULL,
  `FracBank[0][fsklaztec]` int(11) NOT NULL,
  `FracBank[0][fsklrifa]` int(11) NOT NULL,
  `FracBank[0][fsklbiker]` int(11) NOT NULL,
  `FracBank[0][fskllcn]` int(11) NOT NULL,
  `FracBank[0][fsklyak]` int(11) NOT NULL,
  `FracBank[0][fsklrus]` int(11) NOT NULL,
  `FracBank[0][pCena]` int(11) NOT NULL,
  `FracBank[0][pKol]` int(11) NOT NULL,
  `FracBank[0][pSuma]` int(11) NOT NULL,
  `FracBank[0][pCena2]` int(11) NOT NULL,
  `FracBank[0][pKol2]` int(11) NOT NULL,
  `FracBank[0][pSuma2]` int(11) NOT NULL,
  `FracBank[0][nLcn]` int(11) NOT NULL,
  `FracBank[0][nYakuza]` int(11) NOT NULL,
  `FracBank[0][nRm]` int(11) NOT NULL,
  `FracBank[0][lspdbenz]` int(11) NOT NULL,
  `FracBank[0][fbibenz]` int(11) NOT NULL,
  `FracBank[0][vmfbenz]` int(11) NOT NULL,
  `FracBank[0][medsfbenz]` int(11) NOT NULL,
  `FracBank[0][lcnbenz]` int(11) NOT NULL,
  `FracBank[0][yakuzabenz]` int(11) NOT NULL,
  `FracBank[0][medlsbenz]` int(11) NOT NULL,
  `FracBank[0][ballasbenz]` int(11) NOT NULL,
  `FracBank[0][vagosbenz]` int(11) NOT NULL,
  `FracBank[0][pmbenz]` int(11) NOT NULL,
  `FracBank[0][grovebenz]` int(11) NOT NULL,
  `FracBank[0][aztecbenz]` int(11) NOT NULL,
  `FracBank[0][rifabenz]` int(11) NOT NULL,
  `FracBank[0][zonabenz]` int(11) NOT NULL,
  `FracBank[0][pravbenz]` int(11) NOT NULL,
  `FracBank[0][bikerbenz]` int(11) NOT NULL,
  `FracBank[0][kassbenz]` int(11) NOT NULL,
  `FracBank[0][kassnafta]` int(11) NOT NULL,
  `FracBank[0][kassbenzce]` int(11) NOT NULL,
  `FracBank[0][sfpdbenz]` int(11) NOT NULL,
  `FracBank[0][nFond]` int(11) NOT NULL,
  `FracBank[0][musorbak1]` int(11) NOT NULL,
  `FracBank[0][musorbak2]` int(11) NOT NULL,
  `FracBank[0][musorbak3]` int(11) NOT NULL,
  `FracBank[0][musorbak4]` int(11) NOT NULL,
  `FracBank[0][musorbak5]` int(11) NOT NULL,
  `FracBank[0][musorbak6]` int(11) NOT NULL,
  `FracBank[0][musorbak7]` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `frakbank`
--

INSERT INTO `frakbank` (`FracBank[0][fSfnews]`, `FracBank[0][fKazna]`, `healpric`, `addd[0]`, `addd[1]`, `addd[2]`, `FracBank[0][fBMoney]`, `FracBank[0][fBDrugs]`, `FracBank[0][fBMats]`, `FracBank[0][fVMoney]`, `FracBank[0][fVDrugs]`, `FracBank[0][fVMats]`, `FracBank[0][fGMoney]`, `FracBank[0][fGDrugs]`, `FracBank[0][fGMats]`, `FracBank[0][fCMoney]`, `FracBank[0][fCDrugs]`, `FracBank[0][fCMats]`, `FracBank[0][fRMoney]`, `FracBank[0][fRDrugs]`, `FracBank[0][fRMats]`, `FracBank[0][farmmatbi]`, `FracBank[0][farmmatsf]`, `FracBank[0][flspdmatbi]`, `FracBank[0][ffbimats]`, `FracBank[0][fyakuzamats]`, `FracBank[0][frmmats]`, `FracBank[0][flcnmats]`, `FracBank[0][fsfpdmats]`, `FracBank[0][flvpdmats]`, `FracBank[0][fMMoney]`, `FracBank[0][fMDrugs]`, `FracBank[0][fMMats]`, `FracBank[0][fzmatbi]`, `FracBank[0][fzsklad]`, `FracBank[0][fsklballas]`, `FracBank[0][fsklvagos]`, `FracBank[0][fsklgrove]`, `FracBank[0][fsklaztec]`, `FracBank[0][fsklrifa]`, `FracBank[0][fsklbiker]`, `FracBank[0][fskllcn]`, `FracBank[0][fsklyak]`, `FracBank[0][fsklrus]`, `FracBank[0][pCena]`, `FracBank[0][pKol]`, `FracBank[0][pSuma]`, `FracBank[0][pCena2]`, `FracBank[0][pKol2]`, `FracBank[0][pSuma2]`, `FracBank[0][nLcn]`, `FracBank[0][nYakuza]`, `FracBank[0][nRm]`, `FracBank[0][lspdbenz]`, `FracBank[0][fbibenz]`, `FracBank[0][vmfbenz]`, `FracBank[0][medsfbenz]`, `FracBank[0][lcnbenz]`, `FracBank[0][yakuzabenz]`, `FracBank[0][medlsbenz]`, `FracBank[0][ballasbenz]`, `FracBank[0][vagosbenz]`, `FracBank[0][pmbenz]`, `FracBank[0][grovebenz]`, `FracBank[0][aztecbenz]`, `FracBank[0][rifabenz]`, `FracBank[0][zonabenz]`, `FracBank[0][pravbenz]`, `FracBank[0][bikerbenz]`, `FracBank[0][kassbenz]`, `FracBank[0][kassnafta]`, `FracBank[0][kassbenzce]`, `FracBank[0][sfpdbenz]`, `FracBank[0][nFond]`, `FracBank[0][musorbak1]`, `FracBank[0][musorbak2]`, `FracBank[0][musorbak3]`, `FracBank[0][musorbak4]`, `FracBank[0][musorbak5]`, `FracBank[0][musorbak6]`, `FracBank[0][musorbak7]`) VALUES
(194100, 1736908354, 10, 357359, 20, 655411, 121600, 0, 74036, 980701, 0, 42795, 45200, 0, 21200, 28700, 0, 37271, 1410702, 0, 7982, 38800, 62700, 2500, 4800, 35250, 41310, 13600, 32900, 38900, 149920, 1699, 48800, 162900, 500000, 1, 1, 0, 0, 1, 1, 1, 1, 0, 99, 16144, 129040, 99, 1987, 126600, 887501, 79000, 803000, 9150, 7050, 7950, 9700, 2000, 6050, 8500, 6850, 3550, 8250, 0, 0, 7150, 7300, 9050, 9550, 45000, 55000, 8700, 9250, 200000, 1000, 390, 390, 560, 1000, 1000, 190);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
