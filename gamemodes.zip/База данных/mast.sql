-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Час створення: Трв 07 2018 р., 19:36
-- Версія сервера: 5.1.73-log
-- Версія PHP: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `usercT1Z`
--

-- --------------------------------------------------------

--
-- Структура таблиці `mast`
--

CREATE TABLE IF NOT EXISTS `mast` (
  `vID` int(11) NOT NULL AUTO_INCREMENT,
  `vOwned` int(11) NOT NULL,
  `vOwner` varchar(32) NOT NULL,
  `vMessage` varchar(64) NOT NULL,
  `vEntranceX` float NOT NULL,
  `vEntranceY` float NOT NULL,
  `vEntranceZ` float NOT NULL,
  `vBuyPrice` int(11) NOT NULL,
  `vTill` int(11) NOT NULL,
  `vLocked` int(11) NOT NULL,
  `vProducts` int(11) NOT NULL,
  `v2Till` int(11) NOT NULL,
  `vLockTime` int(11) NOT NULL,
  `vBarX` float NOT NULL,
  `vBarY` float NOT NULL,
  `vBarZ` float NOT NULL,
  PRIMARY KEY (`vID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп даних таблиці `mast`
--

INSERT INTO `mast` (`vID`, `vOwned`, `vOwner`, `vMessage`, `vEntranceX`, `vEntranceY`, `vEntranceZ`, `vBuyPrice`, `vTill`, `vLocked`, `vProducts`, `v2Till`, `vLockTime`, `vBarX`, `vBarY`, `vBarZ`) VALUES
(1, 1, 'Michael_Disney', 'Car Service Getto', 2519.97, -1525.42, 23.8089, 3100000, 42800, 0, 45875, 22669480, 0, 2520.05, -1532.89, 23.4946),
(2, 1, 'Johnny_Barnes', 'Car Service LS', -52.3577, -1130.27, 1.0781, 3100000, 32600, 0, 50000, 29667340, 0, -46.2246, -1132.62, 1.0781),
(3, 1, 'Nick_Kave', 'Car Service SF', -2043.23, 81.6285, 28.3906, 3100000, 32600, 0, 47725, 972460, 0, -2053.82, 75.0147, 28.3906),
(4, 1, 'Luke_Disney', 'Car Service LV', 1538.12, 998.03, 10.8203, 3100000, 50000, 0, 50000, 7485090, 0, 1530.5, 998.091, 10.8203);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
